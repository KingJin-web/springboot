package com.king.security.config.login;

import com.alibaba.fastjson.JSONObject;
import com.king.security.entity.User;
import com.king.security.util.MultiReadHttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Component;
import org.springframework.security.core.Authentication;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @program: springboot
 * @description: 自定义用户密码校验过滤器
 * @author: King
 * @create: 2022-03-12 07:41
 */
@Component
public class UserAuthenticationProcessingFilter extends AbstractAuthenticationProcessingFilter {


    /**
     * @param authenticationManager            认证管理器
     * @param userAuthenticationSuccessHandler 认证成功处理
     * @param userAuthenticationFailureHandler 认证失败处理
     */
    public UserAuthenticationProcessingFilter(
                                              UserAuthenticationSuccessHandler userAuthenticationSuccessHandler,
                                              UserAuthenticationFailureHandler userAuthenticationFailureHandler) {
        super(new AntPathRequestMatcher("/login", "POST"));
        this.setAuthenticationSuccessHandler(userAuthenticationSuccessHandler);
        this.setAuthenticationFailureHandler(userAuthenticationFailureHandler);
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request,
                                                HttpServletResponse response)
            throws AuthenticationException {
        if (request.getContentType() == null || !request.getContentType().
                contains("application/json")) {
            throw new AuthenticationServiceException("请求头类型不支持: " +
                    request.getContentType());
        }

        UsernamePasswordAuthenticationToken authRequest;
        try {
            MultiReadHttpServletRequest wrappedRequest = new MultiReadHttpServletRequest(request);
            // 将前端传递的数据转换成jsonBean数据格式
            User user = JSONObject.parseObject(wrappedRequest.getBodyJsonStrByJson(wrappedRequest), User.class);
            authRequest = new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword(), null);
            authRequest.setDetails(authenticationDetailsSource.buildDetails(wrappedRequest));
        } catch (Exception e) {
            throw new AuthenticationServiceException(e.getMessage());
        }
        return this.getAuthenticationManager().authenticate(authRequest);
    }
}
