package com.king.security.config.login;

import com.king.security.entity.User;
import com.king.security.mapper.UserMapper;
import com.king.security.service.UserServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * @program: springboot
 * @description: 自定义认证处理
 * @author: King
 * @create: 2022-03-12 08:28
 */

@Component
public class UserAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    UserServiceImpl userService;
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        // 获取前端表单中输入后返回的用户名、密码
        String userName = (String) authentication.getPrincipal();
        String password = (String) authentication.getCredentials();

        User userInfo = (User) userService.loadUserByUsername(userName);

        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        boolean isValid = encoder.matches(userInfo.getPassword(), password);
        // 验证密码
        if (!isValid) {
            throw new BadCredentialsException("密码错误！");
        }

        return new UsernamePasswordAuthenticationToken(userInfo, password, userInfo.getAuthorities());
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return true;
    }
}
