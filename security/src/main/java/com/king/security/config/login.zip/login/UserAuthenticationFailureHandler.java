package com.king.security.config.login;

import com.alibaba.fastjson.JSON;
import com.king.security.vo.ResultObj;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.*;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @program: springboot
 * @description:
 * @author: King
 * @create: 2022-03-12 07:47
 */
@Slf4j
@Component
public class UserAuthenticationFailureHandler implements AuthenticationFailureHandler {
    @Override
    public void onAuthenticationFailure(HttpServletRequest httpServletRequest, HttpServletResponse response, AuthenticationException e) throws IOException, ServletException {
        ResultObj result = new ResultObj();
        if (e instanceof UsernameNotFoundException || e instanceof BadCredentialsException) {
            result.setMsg(e.getMessage());
        } else if (e instanceof LockedException) {
            result.setMsg("账户被锁定，请联系管理员!");
        } else if (e instanceof CredentialsExpiredException) {
            result.setMsg("证书过期，请联系管理员!");
        } else if (e instanceof AccountExpiredException) {
            result.setMsg("账户过期，请联系管理员!");
        } else if (e instanceof DisabledException) {
            result.setMsg("账户被禁用，请联系管理员!");
        } else {
            //log.error("登录失败：", e);
            result.setMsg("登录失败!");
        }
        PrintWriter out = null;
        try {
            response.setCharacterEncoding("UTF-8");
            response.setContentType("application/json");
            out = response.getWriter();
            out.println(JSON.toJSONString(result));
        } catch (Exception e1) {
            log.error(e1 + "输出JSON出错");
        } finally {
            if (out != null) {
                out.flush();
                out.close();
            }
        }

    }

//    @Override
//    public void onAuthenticationFailure(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AuthenticationException e) throws IOException, ServletException {
//
//    }
}
